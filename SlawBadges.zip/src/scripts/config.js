const STREAMER = 'sirslaw';

const HOUSES = {
  'gryffinclaw': 'h1',
  'lannistark': 'h2',
  'ironbeard': 'h3',
};
